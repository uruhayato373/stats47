// v2 — Compare / Correlation / Blog 3案 (全て1:1対応)

const CMP_SAMPLE = {
  indicator: '一人当たり県民所得', unit: '万円',
  entries: [
    { code: 13, area: '東京都', value: 539, rank: 1 },
    { code: 23, area: '愛知県', value: 382, rank: 2 },
    { code: 47, area: '沖縄県', value: 239, rank: 47 },
  ],
};

function CompareMap() {
  const c = CMP_SAMPLE;
  const colors = [BRAND.primary, BRAND.secondary, BRAND.vermilion];
  return (
    <OGPFrame bg="#F8FAFC">
      <div style={{ position: 'absolute', left: 50, top: -20, width: 1100, height: 680, opacity: 0.22 }}>
        <svg width={1100} height={680} viewBox="0 0 100 100">
          {PREF_DATA.map(p => {
            const idx = c.entries.findIndex(e => e.code === p.code);
            const fill = idx >= 0 ? colors[idx] : '#CBD5E1';
            return <polygon key={p.code} points={p.pts} fill={fill} stroke="#fff" strokeWidth={0.5} strokeLinejoin="round" />;
          })}
        </svg>
      </div>
      <SafeCenter style={{ padding: '44px 32px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, letterSpacing: 4, color: BRAND.primary, fontWeight: 700, marginBottom: 8 }}>COMPARE · 3 PREFECTURES</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 42, color: BRAND.ink, lineHeight: 1.1, letterSpacing: -1 }}>{c.indicator}</div>
        </div>
        <div style={{ width: '100%', background: '#fff', padding: 18, boxShadow: '0 8px 24px rgba(15,23,42,0.10)' }}>
          {c.entries.map((e, i) => (
            <div key={e.code} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: i < 2 ? `1px solid ${BRAND.line}` : 'none' }}>
              <div style={{ width: 14, height: 14, background: colors[i] }} />
              <span style={{ fontFamily: FONT_STACK.sansJP, fontSize: 20, fontWeight: 700, flex: 1 }}>{e.area}</span>
              <span style={{ fontFamily: FONT_STACK.mono, fontSize: 12, color: BRAND.muted }}>#{e.rank}</span>
              <span style={{ fontFamily: FONT_STACK.mono, fontSize: 22, fontWeight: 800, color: colors[i] }}>{e.value}<span style={{ fontSize: 11, color: BRAND.muted, marginLeft: 2 }}>{c.unit}</span></span>
            </div>
          ))}
        </div>
        <Stats47Logo size={14} />
      </SafeCenter>
    </OGPFrame>
  );
}

function CompareVs() {
  const c = CMP_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.04} />
      <SafeCenter style={{ padding: 26, alignItems: 'center' }}>
        <div style={{ width: '100%', paddingBottom: 8, borderBottom: `2px solid ${BRAND.ink}`, textAlign: 'center', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, fontWeight: 700, marginBottom: 18 }}>stats47 · COMPARE</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontSize: 22, color: BRAND.ink, fontWeight: 700, textAlign: 'center' }}>{c.indicator}</div>
        <div style={{ marginTop: 18, width: '100%' }}>
          {c.entries.map((e, i) => (
            <React.Fragment key={e.code}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.muted }}>#{e.rank} / 47</div>
                <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 38, color: BRAND.ink, lineHeight: 1 }}>{e.area}</div>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 46, fontWeight: 900, color: i === 0 ? BRAND.success : i === 2 ? BRAND.vermilion : BRAND.primary, lineHeight: 1, marginTop: 2 }}>{e.value}<span style={{ fontSize: 14, color: BRAND.muted, marginLeft: 3 }}>{c.unit}</span></div>
              </div>
              {i < 2 && <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 24, color: BRAND.muted, textAlign: 'center', margin: '6px 0' }}>vs</div>}
            </React.Fragment>
          ))}
        </div>
        <div style={{ marginTop: 'auto', fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 15, color: BRAND.muted, textAlign: 'center', paddingTop: 12, borderTop: `1px solid ${BRAND.ink}`, width: '100%' }}>
          最大と最小の差 <span style={{ color: BRAND.vermilion, fontWeight: 700 }}>{(c.entries[0].value / c.entries[2].value).toFixed(2)}倍</span>
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

function CompareBrutalist() {
  const c = CMP_SAMPLE;
  const max = Math.max(...c.entries.map(e => e.value));
  const colors = [BRAND.secondary, BRAND.primary, BRAND.vermilion];
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      <div style={{ position: 'absolute', left: -30, top: 80, fontFamily: FONT_STACK.display, fontSize: 420, fontWeight: 900, color: BRAND.secondary, opacity: 0.18, lineHeight: 1, fontStyle: 'italic' }}>vs</div>
      <SafeCenter style={{ padding: '40px 26px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ padding: '4px 10px', background: BRAND.secondary, color: BRAND.ink, display: 'inline-block', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 4, fontWeight: 800 }}>COMPARE · N=3</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 34, color: '#fff', lineHeight: 1.1, marginTop: 12 }}>{c.indicator}</div>
        </div>
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 14 }}>
          {c.entries.map((e, i) => {
            const pct = (e.value / max) * 100;
            return (
              <div key={e.code}>
                <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 4 }}>
                  <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                    <span style={{ fontFamily: FONT_STACK.display, fontSize: 24, fontWeight: 900, color: colors[i], fontStyle: 'italic' }}>#{e.rank}</span>
                    <span style={{ fontFamily: FONT_STACK.sansJP, fontSize: 22, fontWeight: 800 }}>{e.area}</span>
                  </div>
                  <div style={{ fontFamily: FONT_STACK.mono, fontSize: 22, fontWeight: 900, color: colors[i] }}>{e.value}<span style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', marginLeft: 3 }}>{c.unit}</span></div>
                </div>
                <div style={{ height: 14, background: 'rgba(255,255,255,0.08)' }}>
                  <div style={{ width: `${pct}%`, height: '100%', background: colors[i] }} />
                </div>
              </div>
            );
          })}
        </div>
        <Stats47Logo size={14} color="#fff" accent={BRAND.primary} />
      </SafeCenter>
    </OGPFrame>
  );
}

// Correlation
const COR_SAMPLE = { x: '一人当たり県民所得', y: '合計特殊出生率', r: -0.58, n: 47 };

function CorrelationScatter() {
  const c = COR_SAMPLE;
  const points = Array.from({ length: 47 }, (_, i) => {
    const rand = (s) => ((Math.sin(s * 12.9898) * 43758.5453) % 1 + 1) % 1;
    const x = 20 + rand(i) * 70;
    const y = 80 - x * 0.6 + (rand(i + 100) - 0.5) * 20;
    return { x, y };
  });
  return (
    <OGPFrame bg="#FFFFFF">
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, opacity: 0.25 }}>
        {points.map((p, i) => <circle key={i} cx={100 + p.x * 10} cy={60 + p.y * 6} r={3} fill={BRAND.primary} />)}
      </svg>
      <SafeCenter style={{ padding: '40px 32px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, letterSpacing: 4, color: BRAND.primary, fontWeight: 700 }}>CORRELATION · N = {c.n}</div>
        </div>
        <svg width={540} height={260} style={{ background: BRAND.paper, padding: 8 }}>
          {[20,40,60,80].map(v => (
            <g key={v}>
              <line x1={v * 5.4} y1={20} x2={v * 5.4} y2={240} stroke="#E2E8F0" strokeWidth={0.5} />
              <line x1={30} y1={v * 2.6} x2={520} y2={v * 2.6} stroke="#E2E8F0" strokeWidth={0.5} />
            </g>
          ))}
          <line x1={60} y1={220} x2={500} y2={40} stroke={BRAND.vermilion} strokeWidth={1.5} strokeDasharray="4 3" />
          {points.map((p, i) => <circle key={i} cx={30 + p.x * 5.4} cy={p.y * 2.6} r={3} fill={BRAND.primary} />)}
        </svg>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 15, fontWeight: 700 }}>{c.x} × {c.y}</div>
          <div style={{ background: BRAND.ink, color: '#fff', padding: '10px 20px', marginTop: 8, display: 'inline-block' }}>
            <span style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.secondary, letterSpacing: 3 }}>r = </span>
            <span style={{ fontFamily: FONT_STACK.mono, fontSize: 40, fontWeight: 900, color: BRAND.vermilion }}>{c.r}</span>
          </div>
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

function CorrelationEditorial() {
  const c = COR_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.04} />
      <SafeCenter style={{ padding: 28, alignItems: 'center' }}>
        <div style={{ width: '100%', paddingBottom: 8, borderBottom: `2px solid ${BRAND.ink}`, display: 'flex', justifyContent: 'space-between', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, marginBottom: 20 }}>
          <span style={{ fontWeight: 700 }}>stats47 · CORRELATION</span>
          <span style={{ color: BRAND.muted }}>N = {c.n}</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 20, color: BRAND.vermilion, marginBottom: 14 }}>The correlation between</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 40, color: BRAND.ink, lineHeight: 1.1, textAlign: 'center' }}>{c.x}</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 20, color: BRAND.muted, margin: '6px 0' }}>と</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 40, color: BRAND.ink, lineHeight: 1.1, textAlign: 'center' }}>{c.y}</div>
        <div style={{ width: 80, height: 2, background: BRAND.ink, margin: '20px 0' }} />
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.muted, letterSpacing: 2 }}>PEARSON · r</div>
          <div style={{ fontFamily: FONT_STACK.serif, fontSize: 88, fontWeight: 900, color: BRAND.vermilion, fontStyle: 'italic', lineHeight: 1 }}>{c.r}</div>
          <div style={{ fontFamily: FONT_STACK.serif, fontSize: 16, fontWeight: 700 }}>中程度の負の相関</div>
        </div>
        <div style={{ marginTop: 'auto', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.muted }}>— stats47.jp —</div>
      </SafeCenter>
    </OGPFrame>
  );
}

function CorrelationDual() {
  const c = COR_SAMPLE;
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      {/* 左右の羽: 2つの地図 */}
      <div style={{ position: 'absolute', left: 0, top: 40, width: 285, bottom: 40, padding: '0 10px', boxSizing: 'border-box' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.secondary, letterSpacing: 3, marginBottom: 4 }}>X</div>
        <JapanMap width={265} height={470} baseFill="rgba(255,255,255,0.1)"
          valueFn={(code) => ((code * 13) % 47) / 47}
          palette={['rgba(56,189,248,0.2)','rgba(56,189,248,0.4)','rgba(56,189,248,0.7)',BRAND.secondary]}
          strokeColor={BRAND.ink} strokeWidth={0.6} />
      </div>
      <div style={{ position: 'absolute', right: 0, top: 40, width: 285, bottom: 40, padding: '0 10px', boxSizing: 'border-box' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.vermilion, letterSpacing: 3, marginBottom: 4, textAlign: 'right' }}>Y</div>
        <JapanMap width={265} height={470} baseFill="rgba(255,255,255,0.1)"
          valueFn={(code) => 1 - ((code * 13) % 47) / 47}
          palette={['rgba(239,68,68,0.2)','rgba(239,68,68,0.4)','rgba(239,68,68,0.7)',BRAND.vermilion]}
          strokeColor={BRAND.ink} strokeWidth={0.6} />
      </div>
      <SafeCenter style={{ padding: '40px 20px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ padding: '4px 10px', background: BRAND.vermilion, color: '#fff', display: 'inline-block', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 4, fontWeight: 800 }}>CORRELATION</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 20, fontWeight: 800, color: BRAND.secondary }}>{c.x}</div>
          <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 18, color: 'rgba(255,255,255,0.6)', margin: '4px 0' }}>×</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 20, fontWeight: 800, color: BRAND.vermilion }}>{c.y}</div>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, color: BRAND.secondary, letterSpacing: 3 }}>PEARSON r</div>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 88, fontWeight: 900, color: BRAND.vermilion, lineHeight: 1 }}>{c.r}</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>色が反転 = 負の相関</div>
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

// Blog
const BLOG_SAMPLE = { title: '47都道府県で見る「人口減少」の実像', subtitle: '出生率と所得の意外な関係', date: '2026.04.15', category: 'ANALYSIS' };

function BlogMinimal() {
  const b = BLOG_SAMPLE;
  return (
    <OGPFrame bg="#FFFFFF">
      <div style={{ position: 'absolute', left: 0, top: 0, width: 285, height: 630, background: `repeating-linear-gradient(135deg, ${BRAND.paper} 0 20px, #fff 20px 40px)` }} />
      <div style={{ position: 'absolute', right: 0, top: 0, width: 285, height: 630, background: `repeating-linear-gradient(135deg, ${BRAND.paper} 0 20px, #fff 20px 40px)` }} />
      <div style={{ position: 'absolute', left: 285, top: 0, width: 630, height: 630, background: '#fff', boxShadow: '0 0 40px rgba(15,23,42,0.08)' }} />
      <SafeCenter style={{ padding: '48px 36px', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ padding: '3px 10px', background: BRAND.primary, color: '#fff', fontFamily: FONT_STACK.mono, fontSize: 10, fontWeight: 800, letterSpacing: 3 }}>{b.category}</div>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, color: BRAND.muted, letterSpacing: 2 }}>{b.date}</div>
        </div>
        <div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 46, color: BRAND.ink, lineHeight: 1.25, letterSpacing: -1 }}>{b.title}</div>
          <div style={{ width: 60, height: 3, background: BRAND.vermilion, margin: '20px 0' }} />
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 18, color: BRAND.muted, fontWeight: 500 }}>{b.subtitle}</div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 12, borderTop: `1px solid ${BRAND.line}` }}>
          <Stats47Logo size={16} />
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.muted, letterSpacing: 2 }}>stats47.jp/blog</div>
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

function BlogEditorial() {
  const b = BLOG_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.05} />
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {[60, 100, 140, 180, 220, 1020, 1060, 1100, 1140, 1180].map((x, i) =>
          <line key={i} x1={x} y1={20} x2={x} y2={610} stroke={BRAND.ink} strokeWidth={0.3} opacity={0.15} />
        )}
      </svg>
      <SafeCenter style={{ padding: 30, alignItems: 'center' }}>
        <div style={{ width: '100%', paddingBottom: 8, borderBottom: `3px double ${BRAND.ink}`, display: 'flex', justifyContent: 'space-between', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, marginBottom: 20 }}>
          <span style={{ fontWeight: 700 }}>THE STATS47 DISPATCH</span>
          <span style={{ color: BRAND.muted }}>{b.date} · {b.category}</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 18, color: BRAND.vermilion, marginBottom: 10 }}>— Feature</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 48, color: BRAND.ink, lineHeight: 1.15, textAlign: 'center', letterSpacing: -0.5 }}>{b.title}</div>
        <div style={{ width: 80, height: 2, background: BRAND.ink, margin: '20px 0' }} />
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 22, color: BRAND.muted, textAlign: 'center' }}>{b.subtitle}</div>
        <div style={{ marginTop: 'auto', width: '100%', paddingTop: 12, borderTop: `1px solid ${BRAND.ink}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.muted, letterSpacing: 3 }}>stats47.jp/blog</div>
          <Stats47Logo size={16} />
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

function BlogBrutalist() {
  const b = BLOG_SAMPLE;
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, opacity: 0.06 }}>
        <defs>
          <pattern id="blogG" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#fff" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="1200" height="630" fill="url(#blogG)" />
      </svg>
      <div style={{ position: 'absolute', left: -20, top: 40, fontFamily: FONT_STACK.display, fontSize: 360, fontWeight: 900, color: BRAND.primary, opacity: 0.22, lineHeight: 1, fontStyle: 'italic' }}>47</div>
      <div style={{ position: 'absolute', right: -20, bottom: 40, fontFamily: FONT_STACK.display, fontSize: 260, fontWeight: 900, color: BRAND.vermilion, opacity: 0.22, lineHeight: 1, fontStyle: 'italic' }}>.</div>
      <SafeCenter style={{ padding: '40px 30px', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ padding: '4px 12px', background: BRAND.vermilion, color: '#fff', fontFamily: FONT_STACK.mono, fontSize: 10, fontWeight: 900, letterSpacing: 3 }}>{b.category}</div>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: 'rgba(255,255,255,0.6)', letterSpacing: 2 }}>{b.date}</div>
        </div>
        <div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 48, color: '#fff', lineHeight: 1.15, letterSpacing: -1 }}>{b.title}</div>
          <div style={{ width: 60, height: 4, background: BRAND.secondary, margin: '18px 0' }} />
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 18, color: BRAND.secondary, fontWeight: 700 }}>{b.subtitle}</div>
        </div>
        <Stats47Logo size={16} color="#fff" accent={BRAND.primary} />
      </SafeCenter>
    </OGPFrame>
  );
}

Object.assign(window, { CompareMap, CompareVs, CompareBrutalist, CorrelationScatter, CorrelationEditorial, CorrelationDual, BlogMinimal, BlogEditorial, BlogBrutalist });
