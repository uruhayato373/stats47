// v2 — Top ページ 3案 (全て1:1対応)
// 中央 630×630 に重要情報 / 左右 285px はデコレーション

// A. Minimal — 中央ロゴ + 47ドット壁紙
function TopMinimal() {
  return (
    <OGPFrame bg={BRAND.paper}>
      {/* 背景: 47ドットを全面に */}
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0 }}>
        {Array.from({ length: 18 }).map((_, r) =>
          Array.from({ length: 36 }).map((_, c) => {
            const idx = r * 36 + c;
            return <circle key={`${r}-${c}`} cx={20 + c * 33} cy={18 + r * 35} r={3}
              fill={idx % 13 === 0 ? BRAND.vermilion : idx % 7 === 0 ? BRAND.primary : BRAND.line}
              opacity={c < 9 || c > 26 ? 0.7 : 0.35} />;
          })
        )}
      </svg>
      <div style={{ position: 'absolute', left: 285, top: 0, width: 630, height: 630, background: 'rgba(248,250,252,0.92)', backdropFilter: 'blur(2px)' }} />
      <SafeCenter style={{ padding: 40, alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 12, letterSpacing: 5, color: BRAND.primary, fontWeight: 700, marginBottom: 16 }}>47 PREFECTURES · DATA</div>
        <div style={{ fontFamily: FONT_STACK.display, fontSize: 200, fontWeight: 900, color: BRAND.ink, lineHeight: 0.9, letterSpacing: -8, fontStyle: 'italic' }}>
          <span style={{ color: BRAND.primary }}>stats</span>47
        </div>
        <div style={{ width: 80, height: 3, background: BRAND.vermilion, margin: '22px 0' }} />
        <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 28, fontWeight: 700, color: BRAND.ink, textAlign: 'center', lineHeight: 1.35 }}>
          47都道府県を<br/>データで読み解く
        </div>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 12, color: BRAND.muted, letterSpacing: 3, marginTop: 24 }}>stats47.jp</div>
      </SafeCenter>
    </OGPFrame>
  );
}

// B. Editorial — 新聞マストヘッド (中央集約)
function TopEditorial() {
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.05} />
      {/* 左右の装飾: 縦罫 */}
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {[60, 100, 140, 180, 220, 1020, 1060, 1100, 1140, 1180].map((x, i) =>
          <line key={i} x1={x} y1={30} x2={x} y2={600} stroke={BRAND.ink} strokeWidth={0.3} opacity={0.2} />
        )}
      </svg>
      <SafeCenter style={{ padding: 30, alignItems: 'center' }}>
        <div style={{ width: '100%', borderTop: `2px solid ${BRAND.ink}`, borderBottom: `2px solid ${BRAND.ink}`, padding: '6px 0', display: 'flex', justifyContent: 'space-between', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, marginBottom: 30, marginTop: 30 }}>
          <span style={{ fontWeight: 700 }}>VOL. 47</span>
          <span style={{ color: BRAND.muted }}>— THE DATA JOURNAL —</span>
          <span style={{ color: BRAND.muted }}>2026</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 26, color: BRAND.vermilion, marginBottom: 8 }}>An almanac of</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 150, color: BRAND.ink, lineHeight: 0.95, letterSpacing: -4, textAlign: 'center' }}>stats47</div>
        <div style={{ width: 100, height: 2, background: BRAND.ink, margin: '20px 0' }} />
        <div style={{ fontFamily: FONT_STACK.serif, fontSize: 22, color: BRAND.ink, fontWeight: 400, textAlign: 'center', lineHeight: 1.4 }}>47都道府県の<br/>すべてを、数字で。</div>
        <div style={{ marginTop: 'auto', fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.muted, letterSpacing: 4 }}>— stats47.jp —</div>
      </SafeCenter>
    </OGPFrame>
  );
}

// C. Brutalist — ダーク + 大判数字
function TopBrutalist() {
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      {/* 全面グリッド */}
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, opacity: 0.06 }}>
        <defs>
          <pattern id="topBrutG" x="0" y="0" width="24" height="24" patternUnits="userSpaceOnUse">
            <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#fff" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="1200" height="630" fill="url(#topBrutG)" />
      </svg>
      {/* 左右の大判数字をはみ出させる */}
      <div style={{ position: 'absolute', left: -60, top: 80, fontFamily: FONT_STACK.display, fontSize: 520, fontWeight: 900, color: BRAND.primary, opacity: 0.2, lineHeight: 1, fontStyle: 'italic' }}>4</div>
      <div style={{ position: 'absolute', right: -60, top: 80, fontFamily: FONT_STACK.display, fontSize: 520, fontWeight: 900, color: BRAND.vermilion, opacity: 0.2, lineHeight: 1, fontStyle: 'italic' }}>7</div>

      <SafeCenter style={{ padding: 40, alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ padding: '4px 12px', background: BRAND.vermilion, color: '#fff', fontFamily: FONT_STACK.mono, fontSize: 11, letterSpacing: 4, fontWeight: 800, marginBottom: 24 }}>47 PREFECTURES · DATA</div>
        <div style={{ fontFamily: FONT_STACK.display, fontWeight: 900, fontSize: 220, color: '#fff', lineHeight: 0.9, letterSpacing: -8, fontStyle: 'italic' }}>
          stats<span style={{ color: BRAND.secondary }}>47</span>
        </div>
        <div style={{ width: 80, height: 4, background: BRAND.secondary, margin: '24px 0' }} />
        <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 26, fontWeight: 800, color: '#fff', textAlign: 'center', lineHeight: 1.3 }}>日本を、<span style={{ color: BRAND.secondary }}>数字で</span>読む。</div>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, color: 'rgba(255,255,255,0.5)', letterSpacing: 4, marginTop: 26 }}>STATS47.JP</div>
      </SafeCenter>
    </OGPFrame>
  );
}

Object.assign(window, { TopMinimal, TopEditorial, TopBrutalist });
