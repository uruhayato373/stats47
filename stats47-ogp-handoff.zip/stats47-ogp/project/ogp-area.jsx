// v2 — Area Profile 3案 (全て1:1対応)
const AREA_SAMPLE = {
  code: 47, name: '沖縄県', reading: 'OKINAWA',
  strengths: [
    { rank: 1, label: '合計特殊出生率', value: 1.60 },
    { rank: 2, label: '若年人口比率', value: 17.5 },
    { rank: 3, label: '日照時間', value: 1934 },
  ],
  weaknesses: [
    { rank: 47, label: '県民所得', value: 239 },
    { rank: 46, label: '失業率', value: 3.4 },
    { rank: 45, label: '大学進学率', value: 40.2 },
  ],
};

// A. Minimal — 中央に県名+強弱、左右に薄い47グリッド
function AreaMapHighlight() {
  const a = AREA_SAMPLE;
  return (
    <OGPFrame bg={BRAND.paper}>
      {/* 全面: 薄い地図 */}
      <div style={{ position: 'absolute', left: 50, top: -20, width: 1100, height: 680, opacity: 0.18 }}>
        <JapanMap width={1100} height={680} baseFill="#CBD5E1"
          highlight={[a.code]} highlightColor={BRAND.vermilion}
          strokeColor="#fff" strokeWidth={0.6} />
      </div>
      <SafeCenter style={{ padding: '46px 32px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, letterSpacing: 4, color: BRAND.vermilion, fontWeight: 700, marginBottom: 4 }}>AREA #{String(a.code).padStart(2,'0')}</div>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 13, color: BRAND.muted, letterSpacing: 6 }}>{a.reading}</div>
        </div>
        <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 140, color: BRAND.ink, lineHeight: 1, letterSpacing: -3 }}>{a.name}</div>
        <div style={{ width: '100%', background: '#fff', padding: 18, boxShadow: '0 8px 28px rgba(15,23,42,0.1)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 2, color: BRAND.success, fontWeight: 700, marginBottom: 6 }}>▲ STRENGTHS</div>
            {a.strengths.slice(0, 2).map(s => (
              <div key={s.label} style={{ fontFamily: FONT_STACK.sansJP, fontSize: 13, paddingBottom: 3, borderBottom: `1px dotted ${BRAND.line}`, marginBottom: 3 }}>
                <span style={{ fontFamily: FONT_STACK.mono, color: BRAND.success, fontWeight: 700, marginRight: 6, fontSize: 11 }}>#{s.rank}</span>{s.label}
              </div>
            ))}
          </div>
          <div>
            <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 2, color: BRAND.vermilion, fontWeight: 700, marginBottom: 6 }}>▼ WEAKNESSES</div>
            {a.weaknesses.slice(0, 2).map(s => (
              <div key={s.label} style={{ fontFamily: FONT_STACK.sansJP, fontSize: 13, paddingBottom: 3, borderBottom: `1px dotted ${BRAND.line}`, marginBottom: 3 }}>
                <span style={{ fontFamily: FONT_STACK.mono, color: BRAND.vermilion, fontWeight: 700, marginRight: 6, fontSize: 11 }}>#{s.rank}</span>{s.label}
              </div>
            ))}
          </div>
        </div>
        <Stats47Logo size={14} />
      </SafeCenter>
    </OGPFrame>
  );
}

// B. Editorial
function AreaEditorial() {
  const a = AREA_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.04} />
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {[60, 100, 140, 180, 220, 1020, 1060, 1100, 1140, 1180].map((x, i) =>
          <line key={i} x1={x} y1={20} x2={x} y2={610} stroke={BRAND.ink} strokeWidth={0.3} opacity={0.15} />
        )}
      </svg>
      <SafeCenter style={{ padding: 30, alignItems: 'center' }}>
        <div style={{ width: '100%', paddingBottom: 8, borderBottom: `3px double ${BRAND.ink}`, display: 'flex', justifyContent: 'space-between', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, marginBottom: 20 }}>
          <span style={{ fontWeight: 700 }}>AREA PROFILE</span>
          <span style={{ color: BRAND.muted }}>#{String(a.code).padStart(2,'0')} / {a.reading}</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 22, color: BRAND.vermilion, marginBottom: 4 }}>A report on</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 130, color: BRAND.ink, lineHeight: 1, letterSpacing: -2 }}>{a.name}</div>
        <div style={{ width: 80, height: 2, background: BRAND.ink, margin: '18px 0' }} />
        <div style={{ width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          {[
            { title: '強み', en: 'STRENGTHS', items: a.strengths.slice(0, 3), color: BRAND.success },
            { title: '弱み', en: 'WEAKNESSES', items: a.weaknesses.slice(0, 3), color: BRAND.vermilion },
          ].map(col => (
            <div key={col.en}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 6 }}>
                <span style={{ fontFamily: FONT_STACK.serif, fontSize: 20, fontWeight: 900, color: col.color }}>{col.title}</span>
                <span style={{ fontFamily: FONT_STACK.mono, fontSize: 9, color: BRAND.muted, letterSpacing: 2 }}>/ {col.en}</span>
              </div>
              {col.items.map(it => (
                <div key={it.label} style={{ fontFamily: FONT_STACK.serif, fontSize: 14, display: 'flex', justifyContent: 'space-between', paddingBottom: 3, borderBottom: `1px dotted ${BRAND.line}`, marginBottom: 3 }}>
                  <span><span style={{ fontFamily: FONT_STACK.mono, color: BRAND.muted, marginRight: 5, fontSize: 10 }}>#{it.rank}</span>{it.label}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
        <div style={{ marginTop: 'auto', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.muted }}>— stats47.jp —</div>
      </SafeCenter>
    </OGPFrame>
  );
}

// C. Brutalist
function AreaBrutalist() {
  const a = AREA_SAMPLE;
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      {/* 左右の羽: 大判#47 */}
      <div style={{ position: 'absolute', left: -50, top: 50, fontFamily: FONT_STACK.display, fontSize: 440, fontWeight: 900, color: BRAND.vermilion, opacity: 0.3, lineHeight: 1, fontStyle: 'italic' }}>#</div>
      <div style={{ position: 'absolute', right: -50, top: 50, fontFamily: FONT_STACK.display, fontSize: 440, fontWeight: 900, color: BRAND.secondary, opacity: 0.25, lineHeight: 1, fontStyle: 'italic' }}>{a.code}</div>

      <SafeCenter style={{ padding: '40px 30px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ padding: '4px 10px', background: BRAND.vermilion, color: '#fff', display: 'inline-block', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 4, fontWeight: 800 }}>AREA #{String(a.code).padStart(2,'0')}</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 110, color: '#fff', lineHeight: 1, letterSpacing: -3, marginTop: 10 }}>{a.name}</div>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 14, color: BRAND.secondary, letterSpacing: 6, marginTop: 6 }}>{a.reading}</div>
        </div>
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {a.strengths.slice(0, 2).map(s => (
            <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px', background: 'rgba(16,185,129,0.15)', borderLeft: `3px solid ${BRAND.success}` }}>
              <span style={{ fontFamily: FONT_STACK.display, fontSize: 22, fontWeight: 900, color: BRAND.success, fontStyle: 'italic', minWidth: 44 }}>#{s.rank}</span>
              <span style={{ fontFamily: FONT_STACK.sansJP, fontSize: 16, fontWeight: 700, color: '#fff', flex: 1 }}>{s.label}</span>
            </div>
          ))}
          {a.weaknesses.slice(0, 2).map(s => (
            <div key={s.label} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 10px', background: 'rgba(230,57,70,0.15)', borderLeft: `3px solid ${BRAND.vermilion}` }}>
              <span style={{ fontFamily: FONT_STACK.display, fontSize: 22, fontWeight: 900, color: BRAND.vermilion, fontStyle: 'italic', minWidth: 44 }}>#{s.rank}</span>
              <span style={{ fontFamily: FONT_STACK.sansJP, fontSize: 16, fontWeight: 700, color: '#fff', flex: 1 }}>{s.label}</span>
            </div>
          ))}
        </div>
        <Stats47Logo size={14} color="#fff" accent={BRAND.primary} />
      </SafeCenter>
    </OGPFrame>
  );
}

Object.assign(window, { AreaMapHighlight, AreaEditorial, AreaBrutalist });
