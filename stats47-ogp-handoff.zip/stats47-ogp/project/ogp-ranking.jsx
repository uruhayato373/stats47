// v2 — Ranking 3案 (全て1:1対応)
const RANK_SAMPLE = {
  title: '一人当たり県民所得', unit: '万円', source: 'e-Stat / 2023',
  data: [
    { rank:1, name:'東京都', value:539 },
    { rank:2, name:'愛知県', value:382 },
    { rank:3, name:'神奈川県', value:372 },
    { rank:45, name:'青森県', value:259 },
    { rank:46, name:'宮崎県', value:244 },
    { rank:47, name:'沖縄県', value:239 },
  ],
};

// A. Minimal — 中央にTop3、背景全体に薄い地図
function RankingChoropleth() {
  const d = RANK_SAMPLE;
  return (
    <OGPFrame bg="#F8FAFC">
      {/* 背景: 全幅に薄い地図 */}
      <div style={{ position: 'absolute', left: 100, top: -40, width: 1000, height: 700, opacity: 0.25 }}>
        <JapanMap width={1000} height={700} baseFill="#CBD5E1"
          valueFn={(code) => code === 13 ? 1 : code === 23 ? 0.88 : ((code * 11) % 47) / 47}
          palette={['#EFF6FF','#DBEAFE','#BFDBFE','#93C5FD','#60A5FA','#3B82F6','#1D4ED8']}
          strokeColor="#fff" strokeWidth={0.5} />
      </div>
      <SafeCenter style={{ padding: '46px 36px', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, letterSpacing: 4, color: BRAND.primary, fontWeight: 700, marginBottom: 10 }}>RANKING · 47 PREFECTURES</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 44, color: BRAND.ink, lineHeight: 1.15, letterSpacing: -1 }}>{d.title}</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 14, color: BRAND.muted, marginTop: 6 }}>ランキング ({d.unit})</div>
        </div>

        <div style={{ background: '#fff', padding: '18px 22px', boxShadow: '0 10px 32px rgba(15,23,42,0.10)' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.success, fontWeight: 700, marginBottom: 6 }}>▲ TOP 3</div>
          {d.data.slice(0, 3).map((p, i) => (
            <div key={p.rank} style={{ display:'flex', alignItems:'baseline', gap: 12, padding: '6px 0', borderBottom: i < 2 ? `1px solid ${BRAND.line}` : 'none' }}>
              <span style={{ fontFamily: FONT_STACK.display, fontStyle:'italic', fontSize: 30, fontWeight: 900, color: BRAND.ink, minWidth: 48 }}>#{p.rank}</span>
              <span style={{ fontFamily: FONT_STACK.sansJP, fontSize: 20, fontWeight: 700, color: BRAND.ink, flex: 1 }}>{p.name}</span>
              <span style={{ fontFamily: FONT_STACK.mono, fontSize: 22, fontWeight: 800, color: BRAND.ink }}>{p.value}<span style={{ fontSize: 11, color: BRAND.muted, marginLeft: 2 }}>{d.unit}</span></span>
            </div>
          ))}
        </div>

        <div style={{ background: '#fff', padding: '14px 22px', boxShadow: '0 6px 20px rgba(15,23,42,0.06)' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.vermilion, fontWeight: 700, marginBottom: 4 }}>▼ BOTTOM</div>
          <div style={{ display:'flex', alignItems:'baseline', gap: 10 }}>
            <span style={{ fontFamily: FONT_STACK.display, fontStyle:'italic', fontSize: 22, fontWeight: 900, color: BRAND.vermilion, minWidth: 48 }}>#{d.data[5].rank}</span>
            <span style={{ fontFamily: FONT_STACK.sansJP, fontSize: 16, fontWeight: 700, color: BRAND.ink, flex: 1 }}>{d.data[5].name}</span>
            <span style={{ fontFamily: FONT_STACK.mono, fontSize: 18, fontWeight: 800, color: BRAND.vermilion }}>{d.data[5].value}</span>
          </div>
        </div>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', fontFamily: FONT_STACK.mono, fontSize: 10, color: BRAND.muted, letterSpacing: 2 }}>
          <Stats47Logo size={14} /><span>{d.source}</span>
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

// B. Editorial — 新聞風、中央に見出しと三段組
function RankingEditorial() {
  const d = RANK_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.04} />
      {/* 左右: 縦罫 */}
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        {[60, 100, 140, 180, 220, 1020, 1060, 1100, 1140, 1180].map((x, i) =>
          <line key={i} x1={x} y1={20} x2={x} y2={610} stroke={BRAND.ink} strokeWidth={0.3} opacity={0.15} />
        )}
      </svg>
      <SafeCenter style={{ padding: '30px 30px', alignItems: 'center' }}>
        <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, paddingBottom: 8, borderBottom: `3px double ${BRAND.ink}`, marginBottom: 18 }}>
          <span style={{ fontWeight: 700 }}>stats47 · RANKING</span>
          <span style={{ color: BRAND.muted }}>N = 47</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 20, color: BRAND.vermilion, marginBottom: 4 }}>The ranking of</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 52, color: BRAND.ink, lineHeight: 1.1, textAlign: 'center' }}>{d.title}</div>
        <div style={{ width: 80, height: 2, background: BRAND.ink, margin: '16px 0' }} />

        <div style={{ width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginTop: 8 }}>
          <div>
            <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 2, color: BRAND.success, fontWeight: 700, marginBottom: 6 }}>— TOP 3</div>
            {d.data.slice(0, 3).map(p => (
              <div key={p.rank} style={{ fontFamily: FONT_STACK.serif, fontSize: 15, display:'flex', justifyContent:'space-between', paddingBottom: 4, borderBottom: `1px dotted ${BRAND.line}`, marginBottom: 4 }}>
                <span><span style={{ fontFamily: FONT_STACK.mono, color: BRAND.muted, marginRight: 6, fontSize: 11 }}>#{p.rank}</span>{p.name}</span>
                <span style={{ fontFamily: FONT_STACK.mono, fontWeight: 700 }}>{p.value}</span>
              </div>
            ))}
          </div>
          <div>
            <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 2, color: BRAND.vermilion, fontWeight: 700, marginBottom: 6 }}>— BOTTOM 3</div>
            {d.data.slice(3, 6).map(p => (
              <div key={p.rank} style={{ fontFamily: FONT_STACK.serif, fontSize: 15, display:'flex', justifyContent:'space-between', paddingBottom: 4, borderBottom: `1px dotted ${BRAND.line}`, marginBottom: 4 }}>
                <span><span style={{ fontFamily: FONT_STACK.mono, color: BRAND.muted, marginRight: 6, fontSize: 11 }}>#{p.rank}</span>{p.name}</span>
                <span style={{ fontFamily: FONT_STACK.mono, fontWeight: 700 }}>{p.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 'auto', paddingTop: 10, borderTop: `1px solid ${BRAND.ink}`, width: '100%', textAlign: 'center', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.muted }}>— {d.source} · stats47.jp —</div>
      </SafeCenter>
    </OGPFrame>
  );
}

// C. Brutalist — 中央に巨大な#1、左右にランク列
function RankingBrutalist() {
  const d = RANK_SAMPLE;
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      {/* 左右の羽: 縦にランキングバーを並べる */}
      <div style={{ position: 'absolute', left: 24, top: 40, bottom: 40, width: 240, display: 'flex', flexDirection: 'column', gap: 6, opacity: 0.85 }}>
        {Array.from({ length: 23 }).map((_, i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', gap: 6 }}>
            <span style={{ fontFamily: FONT_STACK.mono, fontSize: 9, color: BRAND.secondary, width: 18, textAlign: 'right' }}>#{i + 1}</span>
            <div style={{ flex: 1, height: 10, background: `rgba(56,189,248,${0.8 - i * 0.03})` }} />
          </div>
        ))}
      </div>
      <div style={{ position: 'absolute', right: 24, top: 40, bottom: 40, width: 240, display: 'flex', flexDirection: 'column', gap: 6, opacity: 0.85 }}>
        {Array.from({ length: 23 }).map((_, i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', gap: 6 }}>
            <div style={{ flex: 1, height: 10, background: `rgba(230,57,70,${0.25 + i * 0.025})` }} />
            <span style={{ fontFamily: FONT_STACK.mono, fontSize: 9, color: BRAND.vermilion, width: 22 }}>#{i + 25}</span>
          </div>
        ))}
      </div>

      <SafeCenter style={{ padding: '40px 30px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ padding: '4px 10px', background: BRAND.vermilion, color: '#fff', display: 'inline-block', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 4, fontWeight: 800 }}>RANKING · N=47</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 40, color: '#fff', lineHeight: 1.1, marginTop: 14, letterSpacing: -0.5 }}>{d.title}</div>
        </div>

        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 12, letterSpacing: 4, color: BRAND.secondary, fontWeight: 700 }}>#1</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 86, color: '#fff', lineHeight: 1, letterSpacing: -2 }}>{d.data[0].name}</div>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 72, fontWeight: 900, color: BRAND.secondary, lineHeight: 1, marginTop: 8 }}>{d.data[0].value}<span style={{ fontSize: 22, color: 'rgba(255,255,255,0.5)', marginLeft: 6 }}>{d.unit}</span></div>
        </div>

        <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 2 }}>
          <span style={{ color: 'rgba(255,255,255,0.6)' }}>MAX <b style={{ color: '#fff' }}>{d.data[0].value}</b></span>
          <span style={{ color: 'rgba(255,255,255,0.6)' }}>MIN <b style={{ color: '#fff' }}>{d.data[5].value}</b></span>
          <span style={{ color: 'rgba(255,255,255,0.6)' }}>GAP <b style={{ color: BRAND.vermilion }}>{(d.data[0].value / d.data[5].value).toFixed(1)}×</b></span>
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

Object.assign(window, { RankingChoropleth, RankingEditorial, RankingBrutalist });
