// v2 — Area×Category + Category 3案 (全て1:1対応)

const AC_SAMPLE = {
  code: 47, area: '沖縄県', reading: 'OKINAWA',
  cat: '人口', catEn: 'POPULATION',
  indicators: [
    { rank: 1, label: '合計特殊出生率', value: 1.60, unit: '' },
    { rank: 1, label: '年少人口比率', value: 16.6, unit: '%' },
    { rank: 47, label: '高齢化率', value: 23.1, unit: '%' },
    { rank: 4, label: '人口増減率', value: 0.08, unit: '%' },
  ],
};

// Area×Cat A Minimal
function AreaCatMap() {
  const a = AC_SAMPLE;
  return (
    <OGPFrame bg="#F8FAFC">
      <div style={{ position: 'absolute', left: 50, top: -20, width: 1100, height: 680, opacity: 0.2 }}>
        <JapanMap width={1100} height={680} baseFill="#CBD5E1"
          highlight={[a.code]} highlightColor={BRAND.primary}
          strokeColor="#fff" strokeWidth={0.5} />
      </div>
      <SafeCenter style={{ padding: '44px 32px', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, letterSpacing: 4, color: BRAND.primary, fontWeight: 700 }}>{a.catEn} · #{String(a.code).padStart(2,'0')}</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 22, color: BRAND.muted, marginTop: 6 }}>{a.area}の</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 88, color: BRAND.ink, lineHeight: 1, letterSpacing: -2, marginTop: -2 }}>{a.cat}</div>
        </div>
        <div style={{ width: '100%', background: '#fff', padding: 16, boxShadow: '0 8px 24px rgba(15,23,42,0.08)', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {a.indicators.map(ind => {
            const good = ind.rank <= 10, bad = ind.rank >= 40;
            const col = good ? BRAND.success : bad ? BRAND.vermilion : BRAND.ink;
            return (
              <div key={ind.label} style={{ padding: '8px 10px', borderLeft: `3px solid ${col}` }}>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: col, fontWeight: 700 }}>#{ind.rank}</div>
                <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 12, fontWeight: 600, color: BRAND.ink, marginTop: 2 }}>{ind.label}</div>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 16, fontWeight: 800, color: BRAND.ink, marginTop: 2 }}>{ind.value}<span style={{ fontSize: 9, color: BRAND.muted, marginLeft: 2 }}>{ind.unit}</span></div>
              </div>
            );
          })}
        </div>
        <Stats47Logo size={14} />
      </SafeCenter>
    </OGPFrame>
  );
}

// Area×Cat B Editorial
function AreaCatEditorial() {
  const a = AC_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.04} />
      <SafeCenter style={{ padding: 30, alignItems: 'center' }}>
        <div style={{ width: '100%', paddingBottom: 8, borderBottom: `2px solid ${BRAND.ink}`, display: 'flex', justifyContent: 'space-between', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, marginBottom: 20 }}>
          <span style={{ fontWeight: 700 }}>CATEGORY REPORT</span>
          <span style={{ color: BRAND.muted }}>{a.reading} × {a.catEn}</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontStyle: 'italic', fontSize: 20, color: BRAND.vermilion }}>A study on</div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 70, color: BRAND.ink, lineHeight: 1.1, textAlign: 'center', letterSpacing: -1, marginTop: 8 }}>{a.area}の{a.cat}</div>
        <div style={{ width: 70, height: 2, background: BRAND.ink, margin: '18px 0' }} />
        <div style={{ width: '100%', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {a.indicators.map(ind => {
            const col = ind.rank <= 10 ? BRAND.success : ind.rank >= 40 ? BRAND.vermilion : BRAND.ink;
            return (
              <div key={ind.label} style={{ textAlign: 'center' }}>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 9, color: BRAND.muted }}>#{ind.rank} / 47</div>
                <div style={{ fontFamily: FONT_STACK.serif, fontSize: 22, fontWeight: 900, color: col, marginTop: 4 }}>{ind.value}<span style={{ fontSize: 10, color: BRAND.muted, marginLeft: 2 }}>{ind.unit}</span></div>
                <div style={{ fontFamily: FONT_STACK.serif, fontSize: 11, color: BRAND.ink, fontWeight: 600, marginTop: 2, lineHeight: 1.25 }}>{ind.label}</div>
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 'auto', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.muted }}>— stats47.jp —</div>
      </SafeCenter>
    </OGPFrame>
  );
}

// Area×Cat C Brutalist
function AreaCatBrutalist() {
  const a = AC_SAMPLE;
  return (
    <OGPFrame bg={BRAND.paper}>
      <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 285, background: BRAND.ink, color: '#fff', padding: 28, boxSizing: 'border-box' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.secondary, fontWeight: 700 }}>AREA #{String(a.code).padStart(2,'0')}</div>
        <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 52, color: '#fff', letterSpacing: -1.5, marginTop: 10, lineHeight: 1 }}>{a.area}</div>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 11, color: BRAND.secondary, letterSpacing: 4, marginTop: 10 }}>{a.reading}</div>
        <div style={{ marginTop: 28, paddingTop: 18, borderTop: '1px solid rgba(255,255,255,0.25)' }}>
          <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.secondary }}>CATEGORY</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 800, fontSize: 36, color: '#fff', marginTop: 6 }}>{a.cat}</div>
        </div>
      </div>
      <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: 285, background: BRAND.vermilion, padding: 28, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 10, color: '#fff', letterSpacing: 3, fontWeight: 700 }}>INDICATORS</div>
        <div style={{ fontFamily: FONT_STACK.display, fontSize: 180, fontWeight: 900, color: '#fff', lineHeight: 0.85, fontStyle: 'italic', letterSpacing: -6 }}>{a.indicators.length}</div>
      </div>

      <SafeCenter style={{ padding: '40px 24px', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ padding: '3px 10px', background: BRAND.ink, color: '#fff', display: 'inline-block', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 4, fontWeight: 800 }}>AREA × CATEGORY</div>
          <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 52, color: BRAND.ink, lineHeight: 1.1, letterSpacing: -1, marginTop: 10 }}>{a.area}の<br/>{a.cat}</div>
        </div>
        <div style={{ width: '100%', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {a.indicators.map(ind => {
            const col = ind.rank <= 10 ? BRAND.success : ind.rank >= 40 ? BRAND.vermilion : BRAND.ink;
            return (
              <div key={ind.label} style={{ background: '#fff', border: `2px solid ${col}`, padding: 10 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
                  <span style={{ fontFamily: FONT_STACK.display, fontSize: 22, fontWeight: 900, color: col, fontStyle: 'italic' }}>#{ind.rank}</span>
                  <span style={{ fontFamily: FONT_STACK.mono, fontSize: 9, color: BRAND.muted }}>/47</span>
                </div>
                <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 11, fontWeight: 700, color: BRAND.ink, marginTop: 2 }}>{ind.label}</div>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 14, fontWeight: 800, color: BRAND.ink, marginTop: 2 }}>{ind.value}{ind.unit}</div>
              </div>
            );
          })}
        </div>
        <Stats47Logo size={12} />
      </SafeCenter>
    </OGPFrame>
  );
}

// Category データ
const CAT_SAMPLE = {
  title: '教育', titleEn: 'EDUCATION', indicatorCount: 28,
  featured: [
    { label: '大学進学率', top: '京都府', top_v: 66.2, bottom: '沖縄県', bottom_v: 40.2, unit: '%' },
    { label: '図書館数', top: '東京都', top_v: 383, bottom: '沖縄県', bottom_v: 28, unit: '館' },
    { label: '公立小学校数', top: '北海道', top_v: 988, bottom: '鳥取県', bottom_v: 114, unit: '校' },
  ],
};

// Category A Minimal — 超大判
function CategoryTextHero() {
  const c = CAT_SAMPLE;
  return (
    <OGPFrame bg="#FFFFFF">
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, opacity: 0.4 }}>
        {Array.from({ length: 18 }).map((_, r) =>
          Array.from({ length: 36 }).map((_, c2) => (
            <circle key={`${r}-${c2}`} cx={20 + c2 * 33} cy={18 + r * 35} r={2}
              fill={(r + c2) % 9 === 0 ? BRAND.primary : BRAND.line} />
          ))
        )}
      </svg>
      <div style={{ position: 'absolute', left: 285, top: 0, width: 630, height: 630, background: 'rgba(255,255,255,0.85)' }} />
      <SafeCenter style={{ padding: 40, alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 12, letterSpacing: 5, color: BRAND.primary, fontWeight: 700, marginBottom: 20 }}>CATEGORY / {c.titleEn}</div>
        <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 260, color: BRAND.ink, lineHeight: 0.9, letterSpacing: -10 }}>{c.title}</div>
        <div style={{ width: 80, height: 3, background: BRAND.primary, margin: '24px 0' }} />
        <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 22, color: BRAND.muted }}>
          <span style={{ color: BRAND.primary, fontWeight: 900, fontSize: 28 }}>{c.indicatorCount}</span>指標 × <span style={{ color: BRAND.primary, fontWeight: 900, fontSize: 28 }}>47</span>都道府県
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

// Category B Editorial — 中央三段組
function CategoryTriple() {
  const c = CAT_SAMPLE;
  return (
    <OGPFrame bg="#FAF7F2">
      <Grain opacity={0.04} />
      <SafeCenter style={{ padding: 28, alignItems: 'center' }}>
        <div style={{ width: '100%', paddingBottom: 8, borderBottom: `2px solid ${BRAND.ink}`, fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, textAlign: 'center', marginBottom: 14 }}>
          <span style={{ color: BRAND.vermilion, fontWeight: 700 }}>CATEGORY REPORT · {c.titleEn}</span>
        </div>
        <div style={{ fontFamily: FONT_STACK.serif, fontWeight: 900, fontSize: 74, color: BRAND.ink, lineHeight: 1, textAlign: 'center' }}>{c.title}のいま</div>
        <div style={{ width: 80, height: 2, background: BRAND.ink, margin: '16px 0' }} />
        <div style={{ width: '100%', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginTop: 8 }}>
          {c.featured.map((f, i) => (
            <div key={f.label} style={{ borderRight: i < 2 ? `1px solid ${BRAND.line}` : 'none', paddingRight: i < 2 ? 10 : 0 }}>
              <div style={{ fontFamily: FONT_STACK.serif, fontSize: 13, fontWeight: 700, marginBottom: 8, lineHeight: 1.2 }}>{f.label}</div>
              <div style={{ marginBottom: 6 }}>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 9, letterSpacing: 2, color: BRAND.success, fontWeight: 700 }}>▲ TOP</div>
                <div style={{ fontFamily: FONT_STACK.serif, fontSize: 13, fontWeight: 800 }}>{f.top}</div>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 16, fontWeight: 900, color: BRAND.success }}>{f.top_v}<span style={{ fontSize: 9, color: BRAND.muted }}>{f.unit}</span></div>
              </div>
              <div>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 9, letterSpacing: 2, color: BRAND.vermilion, fontWeight: 700 }}>▼ BTM</div>
                <div style={{ fontFamily: FONT_STACK.serif, fontSize: 13, fontWeight: 800 }}>{f.bottom}</div>
                <div style={{ fontFamily: FONT_STACK.mono, fontSize: 16, fontWeight: 900, color: BRAND.vermilion }}>{f.bottom_v}<span style={{ fontSize: 9, color: BRAND.muted }}>{f.unit}</span></div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 'auto', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 3, color: BRAND.muted }}>— stats47.jp · {c.indicatorCount} indicators —</div>
      </SafeCenter>
    </OGPFrame>
  );
}

// Category C Brutalist — ダーク + ヒートマップ壁紙
function CategoryDotWall() {
  const c = CAT_SAMPLE;
  const seed = (s) => () => ((s = (s*9301+49297) % 233280) / 233280);
  return (
    <OGPFrame bg={BRAND.ink} style={{ color: '#fff' }}>
      <svg width={1200} height={630} style={{ position: 'absolute', inset: 0, opacity: 0.7 }}>
        {Array.from({ length: 14 }).map((_, row) => {
          const r = seed(row + 1);
          return Array.from({ length: 52 }).map((_, col) => {
            const v = r();
            const color = v > 0.8 ? BRAND.secondary : v > 0.55 ? BRAND.primary : v > 0.3 ? '#1E3A8A' : 'rgba(255,255,255,0.04)';
            return <rect key={`${row}-${col}`} x={10 + col * 23} y={20 + row * 42} width={18} height={32} fill={color} />;
          });
        })}
      </svg>
      <div style={{ position: 'absolute', left: 285, top: 0, width: 630, height: 630, background: 'rgba(15,23,42,0.82)' }} />
      <SafeCenter style={{ padding: 40, alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ fontFamily: FONT_STACK.mono, fontSize: 12, letterSpacing: 5, color: BRAND.secondary, fontWeight: 700, marginBottom: 20 }}>CATEGORY / {c.titleEn}</div>
        <div style={{ fontFamily: FONT_STACK.sansJP, fontWeight: 900, fontSize: 210, color: '#fff', lineHeight: 0.9, letterSpacing: -8 }}>{c.title}</div>
        <div style={{ width: 80, height: 4, background: BRAND.secondary, margin: '22px 0' }} />
        <div style={{ fontFamily: FONT_STACK.sansJP, fontSize: 22, color: 'rgba(255,255,255,0.75)' }}>
          <span style={{ color: BRAND.secondary, fontWeight: 900, fontSize: 28 }}>{c.indicatorCount}</span>指標 × <span style={{ color: BRAND.secondary, fontWeight: 900, fontSize: 28 }}>47</span>都道府県
        </div>
      </SafeCenter>
    </OGPFrame>
  );
}

Object.assign(window, { AreaCatMap, AreaCatEditorial, AreaCatBrutalist, CategoryTextHero, CategoryTriple, CategoryDotWall });
