// stats47 OGP — 共通ヘルパー
// ─────────────────────────────────────────────
// - OGPFrame: 1200×630、1:1 セーフゾーンガイド
// - JapanMap: D3的コロプレス地図のスタイライズ版（47県）
// - GridMap47: 格子状の47都道府県ドット配置
// - BarList, ChipRow など

// ブランドパレット
const BRAND = {
  primary: '#2563EB',      // Blue-600
  primaryDark: '#1D4ED8',
  secondary: '#38BDF8',    // Sky-400
  success: '#10B981',      // Emerald-500
  danger: '#EF4444',       // Red-500
  warning: '#F59E0B',      // Amber-500
  ink: '#0F172A',          // Slate-900
  inkSoft: '#1E293B',      // Slate-800
  muted: '#475569',        // Slate-600
  mutedLight: '#94A3B8',   // Slate-400
  line: '#CBD5E1',         // Slate-300
  wash: '#E2E8F0',         // Slate-200
  paper: '#F8FAFC',        // Slate-50
  white: '#FFFFFF',
  // アクセント追加
  vermilion: '#E63946',    // 和の朱
  sumi: '#1A1A1A',         // 墨
  ochre: '#D97706',
};

const FONT_STACK = {
  serif: '"Noto Serif JP", "Times New Roman", "Yu Mincho", serif',
  sans: '"Inter", "Noto Sans JP", system-ui, -apple-system, sans-serif',
  sansJP: '"Noto Sans JP", "Hiragino Sans", system-ui, sans-serif',
  mono: '"JetBrains Mono", "SF Mono", "Menlo", monospace',
  display: '"Archivo Black", "Noto Sans JP", system-ui, sans-serif',
};

// ─────────────────────────────────────────────
// OGPFrame — 1200x630 + セーフゾーン
// 左右の 1:1 クロップ(285-915px) を安全に使うため、
// 重要な情報は中央 630px 内に収める設計。
// ─────────────────────────────────────────────
function OGPFrame({ children, bg = '#fff', showSafe = false, style = {} }) {
  return (
    <div style={{
      width: 1200, height: 630, position: 'relative',
      background: bg, overflow: 'hidden',
      fontFamily: FONT_STACK.sans,
      color: BRAND.ink,
      ...style,
    }}>
      {children}
      {showSafe && (
        <>
          {/* 左右クロップ部分をマスク表示 */}
          <div style={{ position: 'absolute', left: 0, top: 0, width: 285, height: 630, background: 'rgba(255,0,102,0.12)', pointerEvents: 'none', borderRight: '2px dashed #ff0066' }} />
          <div style={{ position: 'absolute', right: 0, top: 0, width: 285, height: 630, background: 'rgba(255,0,102,0.12)', pointerEvents: 'none', borderLeft: '2px dashed #ff0066' }} />
          <div style={{ position: 'absolute', left: 285, top: 4, width: 630, textAlign: 'center', fontFamily: FONT_STACK.mono, fontSize: 10, letterSpacing: 2, color: '#ff0066', fontWeight: 700, pointerEvents: 'none' }}>
            1:1 SAFE ZONE · 630 × 630
          </div>
        </>
      )}
    </div>
  );
}

// セーフエリア矩形の定数 (1:1 クロップ時に残る中央領域)
const SAFE = { left: 285, right: 915, width: 630, top: 0, bottom: 630 };

// ─────────────────────────────────────────────
// JapanMap — スタイライズされた日本地図
// 実データではなく、47県それぞれの概略位置を手書きで近似。
// D3コロプレスの見た目を模した着色ができる。
// valueFn(prefIndex) → 0..1 の正規化値で着色
// highlightIndex → 強調表示する県
// palette: 色スケール（低→高）
// ─────────────────────────────────────────────

// 47都道府県のコード順: 1=北海道 … 47=沖縄
// 地図をごく粗いポリゴン集合で近似（正確ではないが、OGP用のビジュアル）
// 座標系: 0..100 x 0..100
const PREF_DATA = [
  // [code, name, kanji, cx, cy, polygon points (簡略)]
  { code:1, name:'Hokkaido', kanji:'北海道', cx:78, cy:14, pts:'68,3 92,6 96,14 92,24 82,26 70,22 66,14 68,8' },
  { code:2, name:'Aomori', kanji:'青森', cx:77, cy:32, pts:'72,28 84,28 86,34 78,38 70,34' },
  { code:3, name:'Iwate', kanji:'岩手', cx:80, cy:40, pts:'76,36 86,36 88,46 80,48 74,44' },
  { code:4, name:'Miyagi', kanji:'宮城', cx:76, cy:46, pts:'70,44 80,44 82,50 74,52 68,48' },
  { code:5, name:'Akita', kanji:'秋田', cx:72, cy:38, pts:'66,34 76,34 76,42 68,44 64,40' },
  { code:6, name:'Yamagata', kanji:'山形', cx:70, cy:44, pts:'64,42 74,42 74,50 66,52 62,46' },
  { code:7, name:'Fukushima', kanji:'福島', cx:72, cy:52, pts:'66,48 78,48 80,56 70,58 64,54' },
  { code:8, name:'Ibaraki', kanji:'茨城', cx:74, cy:58, pts:'70,55 78,55 80,62 72,64 68,60' },
  { code:9, name:'Tochigi', kanji:'栃木', cx:70, cy:56, pts:'66,53 72,53 74,60 68,61 64,57' },
  { code:10, name:'Gunma', kanji:'群馬', cx:66, cy:58, pts:'62,54 70,54 70,61 64,63 60,58' },
  { code:11, name:'Saitama', kanji:'埼玉', cx:68, cy:62, pts:'64,60 72,60 72,64 66,66 62,63' },
  { code:12, name:'Chiba', kanji:'千葉', cx:74, cy:64, pts:'72,61 78,61 80,67 74,70 72,66' },
  { code:13, name:'Tokyo', kanji:'東京', cx:70, cy:64, pts:'67,63 73,63 73,66 68,67 66,64' },
  { code:14, name:'Kanagawa', kanji:'神奈川', cx:69, cy:67, pts:'65,65 72,65 73,69 67,70 64,67' },
  { code:15, name:'Niigata', kanji:'新潟', cx:64, cy:50, pts:'58,44 68,44 70,54 62,56 56,50' },
  { code:16, name:'Toyama', kanji:'富山', cx:58, cy:54, pts:'54,51 62,51 62,56 56,58 52,55' },
  { code:17, name:'Ishikawa', kanji:'石川', cx:54, cy:52, pts:'50,48 56,48 56,56 52,58 48,52' },
  { code:18, name:'Fukui', kanji:'福井', cx:52, cy:58, pts:'48,55 56,55 56,60 50,62 46,58' },
  { code:19, name:'Yamanashi', kanji:'山梨', cx:66, cy:64, pts:'62,62 68,62 68,66 64,67 60,64' },
  { code:20, name:'Nagano', kanji:'長野', cx:62, cy:58, pts:'58,54 66,54 66,63 60,64 56,60' },
  { code:21, name:'Gifu', kanji:'岐阜', cx:58, cy:60, pts:'54,56 62,56 62,62 56,64 52,60' },
  { code:22, name:'Shizuoka', kanji:'静岡', cx:64, cy:68, pts:'58,64 68,64 70,70 62,72 56,68' },
  { code:23, name:'Aichi', kanji:'愛知', cx:60, cy:66, pts:'56,63 64,63 64,68 58,70 54,66' },
  { code:24, name:'Mie', kanji:'三重', cx:56, cy:68, pts:'52,64 60,64 60,72 54,74 50,68' },
  { code:25, name:'Shiga', kanji:'滋賀', cx:52, cy:62, pts:'48,59 56,59 56,65 50,66 46,62' },
  { code:26, name:'Kyoto', kanji:'京都', cx:48, cy:62, pts:'44,57 52,57 52,66 46,66 42,62' },
  { code:27, name:'Osaka', kanji:'大阪', cx:46, cy:66, pts:'42,64 50,64 50,70 44,71 40,67' },
  { code:28, name:'Hyogo', kanji:'兵庫', cx:42, cy:62, pts:'36,56 48,56 48,66 40,68 34,62' },
  { code:29, name:'Nara', kanji:'奈良', cx:48, cy:68, pts:'44,66 52,66 52,72 46,73 42,69' },
  { code:30, name:'Wakayama', kanji:'和歌山', cx:46, cy:72, pts:'42,70 50,70 50,76 44,78 40,73' },
  { code:31, name:'Tottori', kanji:'鳥取', cx:38, cy:60, pts:'32,57 42,57 42,62 36,63 30,60' },
  { code:32, name:'Shimane', kanji:'島根', cx:32, cy:62, pts:'26,59 36,59 36,64 30,66 24,62' },
  { code:33, name:'Okayama', kanji:'岡山', cx:38, cy:65, pts:'34,62 42,62 42,68 36,69 32,65' },
  { code:34, name:'Hiroshima', kanji:'広島', cx:32, cy:66, pts:'28,63 36,63 36,69 30,70 26,66' },
  { code:35, name:'Yamaguchi', kanji:'山口', cx:26, cy:68, pts:'22,65 30,65 30,71 24,72 18,68' },
  { code:36, name:'Tokushima', kanji:'徳島', cx:40, cy:72, pts:'36,70 44,70 44,75 38,76 34,72' },
  { code:37, name:'Kagawa', kanji:'香川', cx:38, cy:70, pts:'34,68 42,68 42,71 36,72 32,70' },
  { code:38, name:'Ehime', kanji:'愛媛', cx:34, cy:72, pts:'28,69 38,69 38,75 32,76 26,72' },
  { code:39, name:'Kochi', kanji:'高知', cx:34, cy:76, pts:'28,73 40,73 40,78 32,80 26,76' },
  { code:40, name:'Fukuoka', kanji:'福岡', cx:20, cy:70, pts:'16,67 24,67 24,73 18,74 14,70' },
  { code:41, name:'Saga', kanji:'佐賀', cx:16, cy:72, pts:'12,70 20,70 20,74 14,75 10,72' },
  { code:42, name:'Nagasaki', kanji:'長崎', cx:12, cy:74, pts:'8,70 16,70 16,78 10,80 6,74' },
  { code:43, name:'Kumamoto', kanji:'熊本', cx:18, cy:76, pts:'14,73 22,73 22,80 16,81 12,76' },
  { code:44, name:'Oita', kanji:'大分', cx:22, cy:74, pts:'18,71 26,71 26,77 20,78 16,74' },
  { code:45, name:'Miyazaki', kanji:'宮崎', cx:22, cy:80, pts:'18,77 26,77 26,85 20,86 16,81' },
  { code:46, name:'Kagoshima', kanji:'鹿児島', cx:18, cy:84, pts:'14,80 22,80 22,90 16,91 12,84' },
  { code:47, name:'Okinawa', kanji:'沖縄', cx:8, cy:94, pts:'4,92 12,92 12,96 6,97 2,94' },
];

/**
 * JapanMap — スタイライズド日本地図
 * @param {number} width, height — 描画サイズ
 * @param {function(number):number} valueFn — pref.codeを受け取り0-1を返す
 * @param {number[]} highlight — 強調するprefcode配列
 * @param {string[]} palette — 低→高の色配列
 * @param {string} strokeColor, strokeWidth
 */
function JapanMap({
  width = 500, height = 500,
  valueFn = null,
  highlight = [],
  palette = ['#EFF6FF', '#DBEAFE', '#BFDBFE', '#93C5FD', '#60A5FA', '#3B82F6', '#2563EB', '#1D4ED8'],
  strokeColor = '#fff', strokeWidth = 1,
  baseFill = '#E2E8F0',
  highlightColor = null,
  style = {},
}) {
  const lerp = (v) => {
    if (v <= 0) return palette[0];
    if (v >= 1) return palette[palette.length - 1];
    const i = v * (palette.length - 1);
    return palette[Math.floor(i)];
  };
  return (
    <svg width={width} height={height} viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" style={style}>
      {PREF_DATA.map(p => {
        let fill = baseFill;
        if (valueFn) fill = lerp(valueFn(p.code));
        if (highlight.includes(p.code)) fill = highlightColor || BRAND.vermilion;
        return (
          <polygon key={p.code} points={p.pts} fill={fill} stroke={strokeColor} strokeWidth={strokeWidth} strokeLinejoin="round" />
        );
      })}
    </svg>
  );
}

// ─────────────────────────────────────────────
// GridMap47 — 47県のドット/セルグリッド
// 地理的位置を単純化した格子配置（地域ごと）
// 1セル = 1都道府県。ランキングや選択状態を表現
// ─────────────────────────────────────────────
// row, col で配置（地域ごとに塊で）
const PREF_GRID = [
  // 北海道
  {code:1, r:0, c:8, name:'北海道', abbr:'北'},
  // 東北
  {code:2, r:1, c:8, name:'青森', abbr:'青'},
  {code:5, r:2, c:7, name:'秋田', abbr:'秋'},
  {code:3, r:2, c:8, name:'岩手', abbr:'岩'},
  {code:6, r:3, c:7, name:'山形', abbr:'山'},
  {code:4, r:3, c:8, name:'宮城', abbr:'宮'},
  {code:7, r:4, c:8, name:'福島', abbr:'福'},
  // 関東
  {code:9, r:5, c:7, name:'栃木', abbr:'栃'},
  {code:8, r:5, c:8, name:'茨城', abbr:'茨'},
  {code:10, r:6, c:6, name:'群馬', abbr:'群'},
  {code:11, r:6, c:7, name:'埼玉', abbr:'埼'},
  {code:13, r:6, c:8, name:'東京', abbr:'東'},
  {code:12, r:6, c:9, name:'千葉', abbr:'千'},
  {code:14, r:7, c:8, name:'神奈川', abbr:'神'},
  // 中部
  {code:15, r:5, c:6, name:'新潟', abbr:'新'},
  {code:20, r:6, c:5, name:'長野', abbr:'長'},
  {code:19, r:7, c:6, name:'山梨', abbr:'梨'},
  {code:22, r:7, c:7, name:'静岡', abbr:'静'},
  {code:16, r:5, c:5, name:'富山', abbr:'富'},
  {code:17, r:5, c:4, name:'石川', abbr:'石'},
  {code:18, r:6, c:4, name:'福井', abbr:'福井'},
  {code:21, r:6, c:4, name:'岐阜', abbr:'岐'},
  {code:23, r:7, c:5, name:'愛知', abbr:'愛'},
  // 近畿
  {code:25, r:6, c:3, name:'滋賀', abbr:'滋'},
  {code:24, r:7, c:4, name:'三重', abbr:'三'},
  {code:26, r:6, c:2, name:'京都', abbr:'京'},
  {code:27, r:7, c:3, name:'大阪', abbr:'阪'},
  {code:29, r:7, c:2, name:'奈良', abbr:'奈'},
  {code:28, r:6, c:1, name:'兵庫', abbr:'兵'},
  {code:30, r:8, c:3, name:'和歌山', abbr:'和'},
  // 中国
  {code:31, r:5, c:1, name:'鳥取', abbr:'鳥'},
  {code:33, r:6, c:0, name:'岡山', abbr:'岡'},
  {code:32, r:5, c:0, name:'島根', abbr:'島'},
  {code:34, r:7, c:0, name:'広島', abbr:'広'},
  {code:35, r:7, c:1, name:'山口', abbr:'山口'},
  // 四国
  {code:37, r:8, c:1, name:'香川', abbr:'香'},
  {code:36, r:8, c:2, name:'徳島', abbr:'徳'},
  {code:38, r:9, c:1, name:'愛媛', abbr:'媛'},
  {code:39, r:9, c:2, name:'高知', abbr:'高'},
  // 九州
  {code:41, r:8, c:0, name:'佐賀', abbr:'佐'},
  {code:40, r:9, c:0, name:'福岡', abbr:'岡'},
  {code:42, r:10, c:0, name:'長崎', abbr:'長崎'},
  {code:44, r:10, c:1, name:'大分', abbr:'大'},
  {code:43, r:11, c:0, name:'熊本', abbr:'熊'},
  {code:45, r:11, c:1, name:'宮崎', abbr:'宮崎'},
  {code:46, r:12, c:0, name:'鹿児島', abbr:'鹿'},
  // 沖縄
  {code:47, r:12, c:2, name:'沖縄', abbr:'沖'},
];

function GridMap47({
  cellSize = 30, gap = 4,
  valueFn = null,
  highlight = [],
  palette = ['#EFF6FF', '#DBEAFE', '#BFDBFE', '#93C5FD', '#60A5FA', '#3B82F6', '#2563EB'],
  baseFill = '#E2E8F0',
  highlightColor = BRAND.vermilion,
  showLabels = false,
  labelColor = '#fff',
  style = {},
  borderRadius = 3,
}) {
  const cols = 10, rows = 13;
  const W = cols * (cellSize + gap) - gap;
  const H = rows * (cellSize + gap) - gap;
  const lerp = (v) => {
    if (v <= 0) return palette[0];
    if (v >= 1) return palette[palette.length - 1];
    const i = v * (palette.length - 1);
    return palette[Math.floor(i)];
  };
  return (
    <svg width={W} height={H} style={style}>
      {PREF_GRID.map(p => {
        let fill = baseFill;
        if (valueFn) fill = lerp(valueFn(p.code));
        if (highlight.includes(p.code)) fill = highlightColor;
        const x = p.c * (cellSize + gap);
        const y = p.r * (cellSize + gap);
        return (
          <g key={p.code}>
            <rect x={x} y={y} width={cellSize} height={cellSize} rx={borderRadius} fill={fill} />
            {showLabels && (
              <text x={x + cellSize/2} y={y + cellSize/2 + cellSize*0.15} textAnchor="middle"
                fontFamily={FONT_STACK.sansJP} fontWeight={700}
                fontSize={cellSize * 0.42} fill={labelColor}>
                {p.abbr}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ─────────────────────────────────────────────
// WordMark / Logo — stats47 のワードマーク
// ─────────────────────────────────────────────
function Stats47Logo({ size = 28, color = BRAND.ink, accent = BRAND.primary, style = {} }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: size * 0.18, fontFamily: FONT_STACK.sans, ...style }}>
      <span style={{ fontWeight: 900, fontSize: size, color, letterSpacing: -size*0.03, lineHeight: 1 }}>stats</span>
      <span style={{
        fontWeight: 900, fontSize: size, color: BRAND.white,
        background: accent, padding: `${size*0.05}px ${size*0.22}px`,
        borderRadius: size * 0.15, lineHeight: 1,
      }}>47</span>
    </div>
  );
}

// ─────────────────────────────────────────────
// RankBadge — 順位バッジ
// ─────────────────────────────────────────────
function RankBadge({ rank, size = 40, style = {} }) {
  const colors = { 1: '#D4AF37', 2: '#9BA3AF', 3: '#C97A4A' };
  const color = colors[rank] || BRAND.muted;
  return (
    <div style={{
      width: size, height: size, borderRadius: size/2,
      background: color, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: FONT_STACK.sans, fontWeight: 900, fontSize: size * 0.5,
      ...style,
    }}>{rank}</div>
  );
}

// ─────────────────────────────────────────────
// HBar — 水平バー（ランキングチャート用）
// ─────────────────────────────────────────────
function HBar({ label, value, maxValue, color = BRAND.primary, labelColor = BRAND.ink,
               valueColor = BRAND.ink, barHeight = 12, labelWidth = 80,
               valueFormat = (v) => v, unit = '', style = {} }) {
  const pct = Math.max(0, Math.min(100, (value / maxValue) * 100));
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, ...style }}>
      <div style={{ width: labelWidth, fontFamily: FONT_STACK.sansJP, fontWeight: 600, fontSize: 14, color: labelColor }}>{label}</div>
      <div style={{ flex: 1, height: barHeight, background: BRAND.wash, borderRadius: barHeight/2, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: barHeight/2 }} />
      </div>
      <div style={{ fontFamily: FONT_STACK.mono, fontWeight: 700, fontSize: 14, color: valueColor, minWidth: 60, textAlign: 'right' }}>
        {valueFormat(value)}<span style={{ fontSize: 11, color: BRAND.muted, marginLeft: 2 }}>{unit}</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// Grain — ノイズテクスチャ
// ─────────────────────────────────────────────
function Grain({ opacity = 0.04 }) {
  return (
    <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity, mixBlendMode: 'multiply' }}>
      <filter id="noiseFilter">
        <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="3" stitchTiles="stitch" />
      </filter>
      <rect width="100%" height="100%" filter="url(#noiseFilter)" />
    </svg>
  );
}

// ─────────────────────────────────────────────
// SafeCenter — 中央 630×630 の 1:1 セーフゾーン内にコンテンツを配置。
// 左右 285px の余白は装飾/背景用。全コンポーネントの基本レイアウトユニット。
// ─────────────────────────────────────────────
function SafeCenter({ children, style = {} }) {
  return (
    <div style={{
      position: 'absolute', left: 285, top: 0, width: 630, height: 630,
      display: 'flex', flexDirection: 'column',
      boxSizing: 'border-box',
      ...style,
    }}>
      {children}
    </div>
  );
}

Object.assign(window, {
  OGPFrame, JapanMap, GridMap47, Stats47Logo, RankBadge, HBar, Grain, SafeCenter,
  BRAND, FONT_STACK, PREF_DATA, PREF_GRID,
});
